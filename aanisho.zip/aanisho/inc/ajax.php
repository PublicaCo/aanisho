<?php 

/**
 * All AJAX Hooks needed in Plugin
 */

if ( ! defined('ABSPATH')) exit();
if (! defined('PUBLICA_VERSION')) {
    exit;
}




/**
 * Request to get data from publica reportage editor
 */
add_action('wp_ajax_pb_get_editor_data' , 'pb_get_editor_data');
add_action('wp_ajax_nopriv_pb_get_editor_data' , 'pb_get_editor_data');
function pb_get_editor_data(){

    header('Content-Type: application/json; charset=utf-8');

    // check Rate Limit
    PbCheckRateLimit();

    $needed_option = get_option('pb_options', []);
    if (empty($needed_option) || !is_array($needed_option) || !isset($needed_option['reportage_plan']) || !isset($needed_option['plan_category']) ) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(400);
        echo wp_json_encode(['status' => false, 'message' => 'تنظیمات پابلیکا یافت نشد']);
        die();
    }

    // check if request is sent from panel.publica.ir (or PUBLICA_PANEL_DOMAIN)
    $panel_ip = defined('PUBLICA_PANEL_IP') ? PUBLICA_PANEL_IP : '1.1.1.1';
    $origin_or_ref = '';
    if (isset($_SERVER['REMOTE_ADDR']) && !empty($_SERVER['REMOTE_ADDR'])) {
        $origin_or_ref = $_SERVER['REMOTE_ADDR'];
    } else {
        $origin_or_ref = $_SERVER['HTTP_REFERER'] ?: '';
    }

    if (empty($origin_or_ref) || $origin_or_ref !== strtolower($panel_ip)) {
        // set 401 status
        http_response_code(401);
        echo wp_json_encode([
            'status' => false,
            'message' => 'خطای درخواست: منبع درخواست غیرمجاز است'
        ]);
        die();
    }


    // check if content and reportage title and h1 is not empty
    $html_content = $_POST["content"] ?: false;
    $reportage_title = $_POST["title"] ?: false;
    $meta_title = $_POST['meta_title'] ?: false;
    $meta_gist = $_POST['meta_gist'] ?: false;
    $meta_desc = $_POST['meta_desc'] ?: false;
    $tags =  $_POST['selected_tags'] ?: false;


    if( !$html_content || !$reportage_title ){
        http_response_code(400);
        echo wp_json_encode([
            'status' => false,
            'message' => 'لطفا عنوان رپورتاژ و محتوا ارسال شوند'
        ]);
        die();
    }

    // parse html content to fix images and upload them
    $html_content = str_replace('%5C%22' , '' , $html_content);
    $html_content = str_replace('\"' , '' , $html_content);
    $HTMLParser = new HTMLParser( $html_content );
    $parseResult = $HTMLParser->parse();

    $parsed_html = $parseResult->fullContent;
    $count_H1 = $parseResult->elementH1['count'];

    if ($count_H1 > 1){
        http_response_code(400);
        echo wp_json_encode([
            'status' => false,
            'message' => 'افزودن بیش از یک h1 در محتوا مجاز نیست'
        ]);
        die();
    }
    
    // Define reportage post data
    $post_data = array(
        'post_title'    => $reportage_title,
        'post_content'  => $parsed_html,
        'post_status'   => 'publish',
        'post_author'   => intval(function_exists('pb_get_option') ? pb_get_option('author_user_id', 1) : 1),
    );

    // Insert the post into the database
    $post_id = wp_insert_post($post_data);

    if (!$post_id) {
        http_response_code(500);
        echo wp_json_encode([
            'status' => false,
            'message' => 'خطا در انتشار رپورتاژ توسط وبسایت رسانه'
        ]);
        die();
    }

    // Try to set featured image from first <img> in parsed HTML
    try {
        libxml_use_internal_errors(true);
        $imgs = $parseResult->elementImg['items'];
        if( count($imgs) > 0 ){
            $first_img_url = $imgs[0]['src'];
            if (!empty($first_img_url)) {
                $attachment_id = attachment_url_to_postid($first_img_url);
                if ($attachment_id) {
                    set_post_thumbnail($post_id, $attachment_id);
                }
            }
        }
        libxml_clear_errors();
    } catch (Exception $e) {
        // silently ignore
    }

    // now build sent tags in wordpress , but first check if they exist
    if( $tags ){
        $selected_tags_array = explode(',', $tags);
        // Trim spaces around each item
        $selected_tags_array = array_map('trim', $selected_tags_array);
        if( count($selected_tags_array) > 0 ){
            foreach( $selected_tags_array as $tag_item ){
                $exists = term_exists( $tag_item, 'post_tag' );
                if( $exists && !is_wp_error($exists) ){
                    wp_set_post_terms( $post_id, $tag_item, 'post_tag', true );
                }
            }
        }
    }
    

    // get plan category
    $plan_category = get_option('pb_options')['plan_category'];

    if ( !empty($plan_category) ) {
        // attach this existing category id to the post
        wp_set_post_categories( $post_id, array( (int)$plan_category ), true );
    }
    else {
       
        // 1. Try to create the category with given name
        $category_name = function_exists('pb_get_option') ? pb_get_option('category_create_name', 'رپورتاژ آگهی') : 'رپورتاژ آگهی';
        $created_term = wp_insert_term( $category_name, 'category' );

        $created_category_id = $created_term['term_id'];

        // 2. Attach the category to the post
        wp_set_post_categories( $post_id, array( $created_category_id ), true );
    }

    // now remove default category (id = 1) from this post
    wp_remove_object_terms( $post_id, 1, 'category' );

    // check and set meta values 
    if( $meta_title ){
        // Save/update the meta title
        update_post_meta( $post_id, '_custom_meta_title', trim(strip_tags($meta_title)) );
        // Set Yoast SEO meta title
        update_post_meta( $post_id, '_yoast_wpseo_title', trim(strip_tags($meta_title)) );
    }

    if( $meta_desc ){
        // Save/update the meta description
        update_post_meta( $post_id, '_custom_meta_description', trim(strip_tags($meta_desc)) );
        // Set Yoast SEO meta description
        update_post_meta( $post_id, '_yoast_wpseo_metadesc', trim(strip_tags($meta_desc)) );
    }

    echo wp_json_encode([
        'status' => true,
        'message' => 'رپورتاژ با موفقیت منتشر شد',
        'data' => [
            'reportage_link' => get_the_permalink($post_id),
            'title' => $reportage_title,
            'content' => $parsed_html,
        ]
    ]);
    die();
}


/**
 * Proxy: retrieve media plans from panel.publica.ir to avoid CORS in browser
 */
add_action('wp_ajax_pb_get_media_plans_proxy', 'pb_get_media_plans_proxy');
function pb_get_media_plans_proxy(){

	if ( ! current_user_can('manage_options') ) {
		header('Content-Type: application/json; charset=utf-8');
		echo wp_json_encode(['status' => false, 'message' => 'Unauthorized']);
		die();
	}

	$panel_domain = defined('PUBLICA_PANEL_DOMAIN') ? PUBLICA_PANEL_DOMAIN : 'panel.publica.ir';
	$remote_url = 'https://' . $panel_domain . '/wp-admin/admin-ajax.php';

	$args = [
		'method' => 'POST',
		'timeout' => 20,
		'headers' => [
			'Accept' => 'application/json',
		],
		'body' => [
			'action' => 'pb_aanisho_retrieve_media_plans',
		],
	];

	$response = wp_remote_post($remote_url, $args);

	header('Content-Type: application/json; charset=utf-8');
	if (is_wp_error($response)){
		echo wp_json_encode([
			'status' => false,
			'message' => $response->get_error_message(),
		]);
		die();
	}

	$code = wp_remote_retrieve_response_code($response);
	$body = wp_remote_retrieve_body($response);

	if ($code >= 200 && $code < 300){
		// Try pass-through JSON, fallback to wrap
		$decoded = json_decode($body, true);
		if (json_last_error() === JSON_ERROR_NONE){
			echo wp_json_encode($decoded);
		} else {
			echo wp_json_encode(['status' => true, 'raw' => $body]);
		}
	} else {
		echo wp_json_encode([
			'status' => false,
			'code' => $code,
			'message' => 'Remote error',
			'raw' => $body,
		]);
	}
	die();
}

/**
 * Send selected reportage plan to panel.publica.ir
 */
add_action('wp_ajax_pb_save_reportage_plan', 'pb_save_reportage_plan');
function pb_save_reportage_plan() {
	
	if (!current_user_can('manage_options')) {
		header('Content-Type: application/json; charset=utf-8');
		http_response_code(401);
		echo wp_json_encode(['status' => false, 'message' => 'Unauthorized']);
		die();
	}

	$reportage_plan = isset($_POST['reportage_plan']) ? sanitize_text_field($_POST['reportage_plan']) : '';
	$plan_category = isset($_POST['plan_category']) ? sanitize_text_field($_POST['plan_category']) : '';
	$plan_category_name = isset($_POST['plan_category_name']) ? sanitize_text_field($_POST['plan_category_name']) : '';
	
	if (empty($reportage_plan)) {
		header('Content-Type: application/json; charset=utf-8');
		http_response_code(400);
		echo wp_json_encode(['status' => false, 'message' => 'پلن رپورتاژ انتخاب نشده است']);
		die();
	}

    if (empty($plan_category)) {
		header('Content-Type: application/json; charset=utf-8');
		http_response_code(400);
		echo wp_json_encode(['status' => false, 'message' => 'دسته‌بندی پلن رپورتاژ انتخاب نشده است']);
		die();
	}

	$panel_domain = defined('PUBLICA_PANEL_DOMAIN') ? PUBLICA_PANEL_DOMAIN : 'panel.publica.ir';
	$remote_url = 'https://' . $panel_domain . '/wp-admin/admin-ajax.php';

	$args = [
		'method' => 'POST',
		'timeout' => 20,
		'headers' => [
			'Accept' => 'application/json',
		],
		'body' => [
			'action' => 'pb_aanisho_save_reportage_plan',
			'reportage_plan' => $reportage_plan,
			'website_url' => defined('WEBSITE_URL') ? WEBSITE_URL : home_url(),
		],
	];

	$response = wp_remote_post($remote_url, $args);

	header('Content-Type: application/json; charset=utf-8');
	if (is_wp_error($response)) {
		http_response_code(500);
		echo wp_json_encode([
			'status' => false,
			'message' => $response->get_error_message(),
		]);
		die();
	}

	$code = wp_remote_retrieve_response_code($response);
	$body = wp_remote_retrieve_body($response);

	if ($code >= 200 && $code < 300) {
		// Save selected options locally
		$options = get_option('pb_options', []);
		$options['reportage_plan'] = $reportage_plan;
        $options['plan_category'] = $plan_category;
        $options['plan_category_name'] = $plan_category_name;

        // create category from plan category
        if (!empty($plan_category_name)) {
            $created_term = wp_insert_term( $plan_category_name, 'category' );
            if (!is_wp_error($created_term)) {
                $plan_category = $created_term['term_id'];
                $options['plan_category'] = $plan_category;
                $options['plan_category_name'] = $plan_category_name;
            }
            else {
                // find category by name
                $term = get_term_by('name', $plan_category_name, 'category');
                if ($term) {
                    $plan_category = $term->term_id;
                    $options['plan_category'] = $plan_category;
                    $options['plan_category_name'] = $term->name;
                }
                else {
                    $options['plan_category'] = '';
                    $options['plan_category_name'] = '';
                }
            }
        }

        $updated = update_option('pb_options', $options);

		// Try pass-through JSON, fallback to wrap
		$decoded = json_decode($body, true);
		if (json_last_error() === JSON_ERROR_NONE) {
			echo wp_json_encode($decoded);
		} else {
			echo wp_json_encode(['status' => true, 'raw' => $body]);
		}
	} else {
		http_response_code($code);
		echo wp_json_encode([
			'status' => false,
			'code' => $code,
			'message' => 'خطا در ارسال پلن رپورتاژ به پنل',
			'raw' => $body,
		]);
	}
	die();
}

