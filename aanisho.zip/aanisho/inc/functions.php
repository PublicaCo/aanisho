<?php 

/**
 * All function definitions
 */

if ( ! defined('ABSPATH')) exit();
if (! defined('PUBLICA_VERSION')) {
    exit;
}



/**
 * Settings: register options and add admin page
 */
add_action('admin_init', 'pb_register_settings');
add_action('admin_menu', 'pb_add_settings_page');
add_action('admin_enqueue_scripts', 'pb_admin_enqueue_assets');
add_action('update_option_pb_options', 'pb_on_options_update', 10, 2);
add_action('admin_init', 'pb_maybe_redirect_to_publica_settings');

/**
 * Register settings
 */
function pb_register_settings() {
	register_setting('pb_options_group', 'pb_options', 'pb_sanitize_options');

	add_settings_section(
		'pb_main_section',
		__('تنظیمات عمومی پابلیکا', 'publica'),
		function () {
			echo '<p style="margin:0;">' . esc_html__('تنظیمات اتصال و انتشار رپورتاژ', 'publica') . '</p>';
			echo '<p style="background-color: #cc4500; color: #fff; font-weight: bold; padding: 10px; border-radius: 5px;">' . esc_html__('لطفا جهت اتصال افزونه آنی شو به پنل پابلیکا ، ابتدا پلن رپورتاژی که قصد انتشار سریع برای آن را دارید انتخاب نموده و همچنین دسته بندی انتشار را انتخاب نمایید و ذخیره کنید', 'publica') . '</p>';
		},
		'pb_options_page'
	);

	add_settings_field('reportage_plan', __('انتخاب پلن رپورتاژ', 'publica'), function () {
		$options = get_option('pb_options', []);
		$value = isset($options['reportage_plan']) ? $options['reportage_plan'] : '';
		echo '<select name="pb_options[reportage_plan]" id="reportage_plan" class="regular-text" style="width: 300px;">';
		echo '<option value="">' . esc_html__('انتخاب کنید...', 'publica') . '</option>';
		// Options will be populated via AJAX
		echo '</select>';
		echo '<script type="text/javascript">
		jQuery(document).ready(function($) {
			$("#reportage_plan").select2({
				placeholder: "' . esc_js(__('انتخاب پلن رپورتاژ', 'publica')) . '",
				allowClear: true,
				ajax: {
					url: ajaxurl,
					dataType: "json",
					delay: 250,
					data: function (params) {
						return {
							action: "pb_get_media_plans_proxy",
							search: params.term,
							page: params.page || 1
						};
					},
					processResults: function (data) {
						if (data.status && data.data) {
							return {
								results: data.data.map(function(item) {
									return {
										id: item.ID,
										text: item.post_title,
										value: item.ID,
										selected: item.aanisho_selected == 1 ? true : false
									};
								})
							};
						}
						return { results: [] };
					},
					cache: true
				});
		});
		</script>';
	}, 'pb_options_page', 'pb_main_section');

	// Add dependent plan category field
	add_settings_field('plan_category', __('دسته‌بندی پلن', 'publica'), function () {
		$options = get_option('pb_options', []);
		$current_category = isset($options['plan_category']) ? $options['plan_category'] : '';
		echo '<select name="pb_options[plan_category]" id="plan_category" class="regular-text" style="width: 300px;">';
		echo '<option value="">' . esc_html__('ابتدا پلن را انتخاب کنید', 'publica') . '</option>';
		echo '</select>';
		echo '<input type="hidden" id="plan_category_saved_value" value="' . esc_attr($current_category) . '" />';
		echo '<script type="text/javascript">jQuery(function($){ if ($.fn.select2) { $("#plan_category").select2({placeholder: "' . esc_js(__('انتخاب دسته‌بندی', 'publica')) . '", allowClear: true}); } });</script>';
	}, 'pb_options_page', 'pb_main_section');

	

}

/**
 * Add settings page
 */
function pb_add_settings_page() {
	add_options_page(
		__('تنظیمات پابلیکا', 'publica'),
		__('پابلیکا', 'publica'),
		'manage_options',
		'pb-options',
		'pb_render_settings_page'
	);
}

/**
 * Redirect to plugin settings page right after activation
 */
function pb_maybe_redirect_to_publica_settings() {
	// Only run in admin, non-ajax, non-cron, non-rest, with capability
	if ( ! is_admin() ) {
		return;
	}
	if ( defined('DOING_AJAX') && DOING_AJAX ) {
		return;
	}
	if ( defined('DOING_CRON') && DOING_CRON ) {
		return;
	}
	if ( defined('REST_REQUEST') && REST_REQUEST ) {
		return;
	}
	if ( is_network_admin() ) {
		return; // avoid network admin context
	}
	if ( isset($_GET['activate-multi']) ) {
		return; // skip bulk activation
	}
	if ( ! current_user_can('manage_options') ) {
		return;
	}

	$flag = get_option('Activated_publica');
	if ( $flag ) {
		delete_option('Activated_publica');
		$target = admin_url('options-general.php?page=pb-options');
		wp_safe_redirect($target);
		exit;
	}
}



/**
 * Enqueue admin assets
 */
function pb_admin_enqueue_assets($hook_suffix) {
	if ($hook_suffix !== 'settings_page_pb-options') {
		return;
	}
	
	// Enqueue Select2 for the reportage plan field
	wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], '4.1.0-rc.0', true);
	wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', [], '4.1.0-rc.0');
	
	$handle = 'pb-admin-js';
	$src = PUBLICA_PLUGIN_URL . 'assets/pb-admin.js';
	wp_enqueue_script($handle, $src, ['jquery', 'select2'], PUBLICA_VERSION, true);
	$panel_domain = defined('PUBLICA_PANEL_DOMAIN') ? PUBLICA_PANEL_DOMAIN : 'panel.publica.ir';
	$options = get_option('pb_options', []);
	wp_localize_script($handle, 'PBAdmin', [
		'panelDomain' => $panel_domain,
		'websiteUrl' => WEBSITE_URL,
		'savedPlanCategory' => isset($options['plan_category']) ? $options['plan_category'] : '',
	]);
}


/**
 * Render settings page
 */
function pb_render_settings_page() {
	if (!current_user_can('manage_options')) {
		return;
	}
	?>
	<div class="wrap" style="direction: rtl; text-align: right;">
		<h1><?php echo esc_html(__('تنظیمات پابلیکا', 'publica')); ?></h1>
		<form method="post" action="options.php">
			<div id="pb_error_message" style="color: red;"></div>
			<div id="pb_success_message" style="color: green;"></div>
			<?php
			settings_fields('pb_options_group');
			do_settings_sections('pb_options_page');
			submit_button(__('ذخیره تغییرات', 'publica'));
			?>
		</form>
	</div>
	<?php
}

function pb_sanitize_options($input) {
	$sanitized = [];
	$sanitized['reportage_plan'] = isset($input['reportage_plan']) ? sanitize_text_field($input['reportage_plan']) : '';
	$sanitized['plan_category'] = isset($input['plan_category']) ? sanitize_text_field($input['plan_category']) : '';
	return $sanitized;
}

/**
 * Handle options update - send reportage plan to panel
 */
function pb_on_options_update($old_value, $new_value) {
	// Check if reportage_plan was updated
	if (isset($new_value['reportage_plan']) && !empty($new_value['reportage_plan'])) {
		$old_plan = isset($old_value['reportage_plan']) ? $old_value['reportage_plan'] : '';
		$new_plan = $new_value['reportage_plan'];
		
		// Only send if the value actually changed
		if ($old_plan !== $new_plan) {
			pb_send_reportage_plan_to_panel($new_plan);
		}
	}
}

/**
 * Send reportage plan to panel.publica.ir
 */
function pb_send_reportage_plan_to_panel($reportage_plan) {
	$panel_domain = defined('PUBLICA_PANEL_DOMAIN') ? PUBLICA_PANEL_DOMAIN : 'panel.publica.ir';
	$remote_url = 'https://' . $panel_domain . '/wp-admin/admin-ajax.php';

	$args = [
		'method' => 'POST',
		'timeout' => 20,
		'headers' => [
			'Accept' => 'application/json',
		],
		'body' => [
			'action' => 'pb_aanisho_save_reportage_plan',
			'reportage_plan' => $reportage_plan,
			'website_url' => defined('WEBSITE_URL') ? WEBSITE_URL : home_url(),
		],
	];

	$response = wp_remote_post($remote_url, $args);

	die(print_r($response, true));
	
	// Log the response for debugging (optional)
	if (is_wp_error($response)) {
		error_log('Publica Plugin: Failed to send reportage plan to panel - ' . $response->get_error_message());
	} else {
		$code = wp_remote_retrieve_response_code($response);
		if ($code < 200 || $code >= 300) {
			error_log('Publica Plugin: Panel returned error code ' . $code . ' when saving reportage plan');
		}
	}
}

function pb_get_option($key, $default = null) {
	$options = get_option('pb_options', []);
	return isset($options[$key]) ? $options[$key] : $default;
}

/**
 * Include Rate Limit functionality (By Requester IP Address)
 */
function PbCheckRateLimit() {

    date_default_timezone_set('Asia/Tehran');
    session_start();

    // using the originating IP
    $rateLimiter = new RateLimiter($_SERVER["REMOTE_ADDR"]);

    $limit = 2; // number of connections to limit user to per $minutes
    $minutes = 1;   // number of $minutes to check for.
    $seconds = floor($minutes * 60);	//	retry after $minutes in seconds.

    try {
        $rateLimiter->limitRequestsInMinutes($limit, $minutes);
    } catch (RateExceededException $e) {
        header("HTTP/1.1 429 Too Many Requests");
        header(sprintf("Retry-After: %d", $seconds));
        $data = array(
            'status' => false,
            'message' => 'محدودیت تعداد درخواست. لطفا پس از گذشت یک دقیقه مجددا امتحان کنید'
        );
        die (json_encode($data));
    }

}




/**
 * attached to Activation Hook
 */
function pbPluginActivation() {
    if ( version_compare( $GLOBALS['wp_version'], PUBLICA_MINIMUM_WP_VERSION, '<' ) ) {
        load_plugin_textdomain( 'publica' );

        $message = '<strong>' .
            /* translators: 1: Current publica version number, 2: Minimum WordPress version number required. */
            sprintf( esc_html__( 'Publica %1$s requires WordPress %2$s or higher.', 'publica' ), PUBLICA_VERSION, PUBLICA_MINIMUM_WP_VERSION ) . '</strong> ' .
            /* translators: 1: WordPress documentation URL, 2: publica download URL. */
            sprintf( __( 'Please <a href="%1$s">upgrade WordPress</a> to a current version, or <a href="%2$s">downgrade to version 2.4 of the publica plugin</a>.', 'publica' ), 'https://codex.wordpress.org/Upgrading_WordPress', 'https://wordpress.org/plugins/publica' );

        echo $message;
    } elseif ( ! empty( $_SERVER['SCRIPT_NAME'] ) && false !== strpos( $_SERVER['SCRIPT_NAME'], '/wp-admin/plugins.php' ) ) {
        add_option( 'Activated_publica', true );
    }
}



/**
 * attached to Uninstall Hook
 */
function pbPluginUninstall() {
	// Remove plugin options on uninstall
	delete_option( 'pb_options' );
	if ( is_multisite() ) {
		delete_site_option( 'pb_options' );
	}
}