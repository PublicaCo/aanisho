(function(){
	var $ = jQuery;
	function pretty(obj){ try { return JSON.stringify(obj, null, 2); } catch(e){ return String(obj); } }

	document.addEventListener('DOMContentLoaded', function(){
		if(!$('#reportage_plan')){ return; }

		var mediaPlans = [];

		function populateCategoriesForPlan(planId){
			var $cat = $('#plan_category');
			if(!$cat.length){ return; }
			$cat.empty();
			$cat.append(new Option('ابتدا پلن را انتخاب کنید', '', false, false));
			if(!planId){ if (jQuery.fn && jQuery.fn.select2) { $cat.trigger('change.select2'); } return; }
			var plan = mediaPlans.find(function(p){ return String(p.ID) === String(planId); });
			if(!plan){ if (jQuery.fn && jQuery.fn.select2) { $cat.trigger('change.select2'); } return; }
			var categories = plan.plan_category || plan.plan_categories || plan.categories || [];
			// Normalize to array of {id, text}
			var normalized = [];
			if (Array.isArray(categories)){
				categories.forEach(function(c){
					if (c && typeof c === 'object'){
						var id = c.term_id;
						var text = c.name || String(id);
						normalized.push({ id: id, text: text });
					} else if (typeof c === 'string' || typeof c === 'number'){
						normalized.push({ id: c, text: String(c) });
					}
				});
			}
			if (normalized.length === 0){ if (jQuery.fn && jQuery.fn.select2) { $cat.trigger('change.select2'); } return; }
			var saved = (window.PBAdmin && PBAdmin.savedPlanCategory) ? PBAdmin.savedPlanCategory : ($('#plan_category_saved_value').val() || '');
			normalized.forEach(function(opt){
				var selected = saved && String(saved) === String(opt.id);
				$cat.append(new Option(opt.text, opt.id, selected, selected));
			});
			if (jQuery.fn && jQuery.fn.select2) { $cat.trigger('change.select2'); }
		}

		// Preload media plans on page load and populate the select
		(function preloadMediaPlans(){
			var url = (window.ajaxurl) ? window.ajaxurl : (window.PBAdmin && PBAdmin.ajaxUrl ? PBAdmin.ajaxUrl : '');
			if(!url){ return; }
			var form = new FormData();
			form.append('action', 'pb_get_media_plans_proxy');
			fetch(url, {
				method: 'POST',
				credentials: 'include',
				body: form,
			}).then(function(res){
				return res.json();
			}).then(function(json){
				if(!json || !json.status || !json.data){ return; }
				mediaPlans = json.data || [];
				var $select = $('#reportage_plan');
				// If already has options, keep current selection
				var currentVal = $select.val();
				$select.empty();
				$select.append(new Option('انتخاب کنید...', '', false, false));
				mediaPlans.forEach(function(item){
					var selected = item.aanisho_selected == 1;
					var opt = new Option(item.post_title, item.ID, selected, selected);
					$select.append(opt);
				});
				// Restore selection if existed
				if(currentVal){ $select.val(currentVal); }
				// Refresh select2 if present
				if (jQuery.fn && jQuery.fn.select2) { $select.trigger('change.select2'); }
				// Populate categories for current selection
				populateCategoriesForPlan($select.val());
			}).catch(function(){ /* silent */ });
		})();


		// When reportage plan changes, repopulate categories
		$('body').on('change', '#reportage_plan', function(){
			populateCategoriesForPlan($(this).val());
		});

		// Save reportage plan
		$('body').delegate('#submit', 'click', function(e){
			e.preventDefault();

			var btn = $(this);
			
			var selectedPlanId = $('#reportage_plan').val();
			var selectedCategory = $('#plan_category').val() || '';
			var selectedCategoryName = $('#plan_category').find('option:selected').text() || '';

			var url = (window.ajaxurl) ? window.ajaxurl : (window.PBAdmin && PBAdmin.ajaxUrl ? PBAdmin.ajaxUrl : '');
			if(!url){ console.log('Missing ajaxurl'); return; }

			var form = new FormData();
			form.append('action', 'pb_save_reportage_plan');
			form.append('reportage_plan', selectedPlanId);
			form.append('plan_category', selectedCategory);
			form.append('plan_category_name', selectedCategoryName);

			btn.prop('disabled', true);
			btn.val('در حال ارسال...');

			fetch(url, {
				method: 'POST',
				credentials: 'include',
				body: form,
			}).then(function(res){
				return res.json();
			}).then(function(json){
				btn.prop('disabled', false);
				btn.val('ذخیره تغییرات');
				$('#pb_error_message').html('');
				$('#pb_success_message').html('');
				$("#pb_error_message").css({display: 'none'});
				$("#pb_success_message").css({display: 'none'});
				if(json.status){
					$('#pb_success_message').html(json.message);
					$("#pb_success_message").css({
						display: 'block',
						background: '#aef5ae',
						color: '#0b510b',
						padding: '10px',
						'font-weight': 'bold',
						'border': '1px solid #00c300',
					});
				}else{
					$('#pb_error_message').html(json.message);
					$("#pb_error_message").css({
						display: 'block',
						background: '#ffa6a6',
						color: '#990000',
						padding: '10px',
						'font-weight': 'bold',
						'border': '1px solid #ff0000',
					});
				}
			}).catch(function(err){
				btn.prop('disabled', false);
				btn.val('ذخیره تغییرات');
				$('#pb_error_message').html('');
				$('#pb_success_message').html('');
				$("#pb_error_message").css({display: 'none'});
				$("#pb_success_message").css({display: 'none'});
			});
		});
	});
})();


