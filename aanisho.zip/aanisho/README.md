Publica Instantly publishes reportages from panel dashboard and reportage editor while completing content from customer panel. 
just by installing this plugin in publisher wordpress website
